# Picture Lab (Python)

A Python port of the AP CSA Picture Lab, redesigned around plain numpy
arrays instead of a class hierarchy, with a pixel-grid inspector so the
encoding of an image is visible while you edit it.

A "picture" here is just a numpy array of shape `(height, width, 3)`,
dtype `uint8`. No `Picture`/`Pixel`/`SimplePicture` classes -- reading and
writing pixels is direct array indexing, which is also how you'll treat
images once this course moves into actual model work.

## Project layout

```
src/piclab/
  io_utils.py         load_image / save_image / blank_canvas
  transforms.py        loop-based pixel transforms (zero_blue, mirror_vertical, ...)
  fast_transforms.py   the same transforms, vectorized with numpy
  encoding.py           hex / binary / packed-int views of a pixel
notebooks/
  01_pixel_inspector.ipynb   interactive pixel-grid inspector (ipywidgets)
desktop_app/
  pixel_inspector_tk.py       same idea, standalone Tkinter app
tests/
  test_transforms.py
images/                sample images (from the original Java lab)
```

## Running it

### Option A: GitHub Codespaces (recommended)

1. Open this repo on GitHub, click **Code > Create codespace on main**.
2. Wait for the container to build (installs everything from
   `requirements.txt` automatically, nothing to configure).
3. Open `notebooks/01_pixel_inspector.ipynb` and run the cells top to
   bottom.

No local install, no Google account -- just a GitHub account, which the
district already provides.

### Option B: Standalone desktop app

Needs a local Python 3.10+ with `numpy` and `Pillow` installed
(`pip install -r requirements.txt`), and Tkinter, which ships with most
Python installers on Windows/Mac by default.

```
python desktop_app/pixel_inspector_tk.py images/beach.jpg
```

Drag a box on the image to zoom into that region; click any cell in the
zoomed grid to see its exact R/G/B, hex, binary, and packed-integer
encoding.

## Tests

```
pip install -e .
pytest
```

## For students: where to start editing

Open `src/piclab/transforms.py`. Every function there takes a pixel array
in and returns a new one out -- `zero_blue`, `mirror_vertical`,
`mirror_region`, `copy_into`, `edge_detection`. Add new functions the same
way, then try them in the notebook or the desktop app.

`fast_transforms.py` has vectorized versions of the same functions, for
comparing explicit pixel loops against numpy array operations once that
lesson comes up.
